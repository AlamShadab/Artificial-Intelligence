# Google-Chrome-Dino-Game-AI

It's Finally here

Sorry about the wait, but here is the source code for my dinosaur Ai video
get processing https://processing.org/download/
Some controls:
press G to show all of the generations where the dinosaurs improved
press N to show Nothing (to speed up the evolution)
+ and - adjust the game speed

have fun
